﻿#include <conio.h>  // Для работы с _kbhit() и _getch()
#include <iostream>
#include <Windows.h>

using namespace std; // Используем стандартное пространство имён для удобства

// Константы для размера игрового поля
const int width = 60;	// Ширина поля
const int height = 20;	// Высота поля

// Структура для хранения состояния игры
struct Game
{
	bool gameOver;	// Флаг окончания игры
	int x, y;	// Координаты головы змеи
	int fruitX, fruitY;	// Координаты фрукта
	int score;	// Счет игрока
	int* snakeX;	// Массив X-координат змеи
	int* snakeY;	// Массив Y-координат змеи
	int snakeCapacity;	// Вместимость массивов змеи
	int snakeLength;	// Текущая длина змеи
	enum eDirection { STOP = 0, LEFT, RIGHT, UP, DOWN } dir;	// Направление движения
	HANDLE hConsole;	// Хэндл консоли
	int lastTailX, lastTailY;	// Координаты последнего хвоста для очистки
};

// Инициализация игры
void InitGame(Game& game)
{
	game.gameOver = false;	// Игра не окончена
	game.dir = Game::STOP;	// Начальное направление - остановка
	game.x = width / 2;	// Стартовая позиция X головы
	game.y = height / 2;	// Стартовая позиция Y головы
	game.fruitX = rand() % width;	// Случайная позиция фрукта X
	game.fruitY = rand() % height;	// Случайная позиция фрукта Y
	game.score = 0;	// Начальный счет

	game.snakeCapacity = 10;	// Начальная емкость массива змеи
	game.snakeLength = 1;	// Начальная длина змеи
	game.snakeX = new int[game.snakeCapacity];	// Выделение памяти для X-координат
	game.snakeY = new int[game.snakeCapacity];	// Выделение памяти для Y-координат
	game.snakeX[0] = game.x;	// Установка начальной позиции головы
	game.snakeY[0] = game.y;

	game.lastTailX = -1;	// Инициализация последнего хвоста
	game.lastTailY = -1;

	game.hConsole = GetStdHandle(STD_OUTPUT_HANDLE); // Получение хэндла консоли

	// Настройка курсора консоли
	CONSOLE_CURSOR_INFO cursorInfo;
	cursorInfo.dwSize = 1; // Размер курсора
	cursorInfo.bVisible = FALSE; // Скрытие курсора
	SetConsoleCursorInfo(game.hConsole, &cursorInfo);

	// Отрисовка статичной рамки
	system("cls"); // Очистка консоли
	// Верхняя граница
	for (int i = 0; i < width + 2; i++) cout << "#";
	cout << endl;
	// Боковые границы и пустое поле
	for (int i = 0; i < height; i++)
	{
		cout << "#"; // Левая граница
		for (int j = 0; j < width; j++) cout << " "; // Пустое поле
		cout << "#" << endl; // Правая граница
	}
	// Нижняя граница
	for (int i = 0; i < width + 2; i++) cout << "#";
	cout << endl;
}

// Увеличение размера массива змеи
void ExpandSnake(Game& game)
{
	int newCapacity = game.snakeCapacity * 2; // Удвоение емкости
	int* newX = new int[newCapacity]; // Новый массив X
	int* newY = new int[newCapacity]; // Новый массив Y

	// Копирование старых данных
	for (int i = 0; i < game.snakeLength; i++) {
		newX[i] = game.snakeX[i];
		newY[i] = game.snakeY[i];
	}

	// Освобождение старой памяти
	delete[] game.snakeX;
	delete[] game.snakeY;

	// Обновление указателей
	game.snakeX = newX;
	game.snakeY = newY;
	game.snakeCapacity = newCapacity;
}

// Рисование символа в заданной позиции
void DrawChar(int x, int y, char c)
{
	COORD pos = { x + 1, y + 1 }; // Позиция с учетом рамки
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos); // Установка позиции
	cout << c; // Вывод символа
}

// Отрисовка игрового состояния
void Draw(Game& game)
{
	// Стираем последний хвост
	if (game.lastTailX != -1 && game.lastTailY != -1)
	{
		DrawChar(game.lastTailX, game.lastTailY, ' ');
	}

	// Рисуем фрукт
	DrawChar(game.fruitX, game.fruitY, 'F');

	// Рисуем голову змеи
	DrawChar(game.snakeX[0], game.snakeY[0], 'O');

	// Рисуем тело змеи
	for (int i = 1; i < game.snakeLength; i++)
	{
		DrawChar(game.snakeX[i], game.snakeY[i], 'o');
	}

	// Сохраняем последний хвост
	if (game.snakeLength > 0)
	{
		game.lastTailX = game.snakeX[game.snakeLength - 1];
		game.lastTailY = game.snakeY[game.snakeLength - 1];
	}

	// Вывод счета
	COORD pos = { 0, height + 2 };
	SetConsoleCursorPosition(game.hConsole, pos);
	cout << "Счёт: " << game.score << " | Длина: " << game.snakeLength << "    ";
}

// Обработка ввода пользователя
void Input(Game& game)
{
	if (_kbhit())
	{ // Если нажата клавиша
		switch (_getch())
		{ // Получаем нажатую клавишу
		case 'a': if (game.dir != Game::RIGHT) game.dir = Game::LEFT; break;
		case 'd': if (game.dir != Game::LEFT) game.dir = Game::RIGHT; break;
		case 'w': if (game.dir != Game::DOWN) game.dir = Game::UP; break;
		case 's': if (game.dir != Game::UP) game.dir = Game::DOWN; break;
		case 'x': game.gameOver = true; break; // Выход из игры
		}
	}
}

// Логика игры
void Logic(Game& game)
{
	int prevX = game.snakeX[0]; // Предыдущая позиция головы
	int prevY = game.snakeY[0];
	int prev2X, prev2Y;

	// Движение головы
	switch (game.dir)
	{
	case Game::LEFT: game.x--; break;
	case Game::RIGHT: game.x++; break;
	case Game::UP: game.y--; break;
	case Game::DOWN: game.y++; break;
	}

	// Проверка столкновения с границами
	if (game.x < 0 || game.x >= width || game.y < 0 || game.y >= height)
		game.gameOver = true;

	// Проверка столкновения с телом
	for (int i = 1; i < game.snakeLength; i++)
	{
		if (game.snakeX[i] == game.x && game.snakeY[i] == game.y)
			game.gameOver = true;
	}

	// Проверка съедания фрукта
	if (game.x == game.fruitX && game.y == game.fruitY)
	{
		game.score += 10; // Увеличение счета
		game.fruitX = rand() % width; // Новый фрукт
		game.fruitY = rand() % height;

		if (game.snakeLength >= game.snakeCapacity) // Расширение при необходимости
			ExpandSnake(game);

		game.snakeX[game.snakeLength] = -1; // Добавление нового сегмента
		game.snakeY[game.snakeLength] = -1;
		game.snakeLength++; // Увеличение длины
	}

	// Обновление позиций сегментов
	game.snakeX[0] = game.x;
	game.snakeY[0] = game.y;
	for (int i = 1; i < game.snakeLength; i++)
	{
		prev2X = game.snakeX[i];
		prev2Y = game.snakeY[i];
		game.snakeX[i] = prevX;
		game.snakeY[i] = prevY;
		prevX = prev2X;
		prevY = prev2Y;
	}
}

int main() {
	setlocale(LC_ALL, "RUS"); // Устанавливаем для корректного отображения текста на русском
	srand(time(0)); // Инициализация генератора случайных чисел
	Game game; // Создание экземпляра игры
	InitGame(game); // Инициализация игры

	// Главный игровой цикл
	while (!game.gameOver)
	{
		Draw(game); // Отрисовка
		Input(game); // Ввод
		Logic(game); // Логика
		Sleep(100);  // Задержка (скорость игры)
	}

	// Освобождение памяти
	delete[] game.snakeX;
	delete[] game.snakeY;

	// Вывод итогового счета
	COORD pos = { 0, height + 3 };
	SetConsoleCursorPosition(game.hConsole, pos);
	cout << "Конец игры! Итоговый счёт: " << game.score;

	Sleep(2000); // Задержка перед выходом
	return 0;
}